package Notes;

/*
THIS IS AN EXAMPLE OF SYNTAX FOR A PREPARED STATEMENT
 */


/**
 *
 * @author hanna
 */
public class PreparedStatementExample {
    public static void c(){
    String sql = "INSERT INTO EMPLOYEE (ID,FIRST_NAME,LAST_NAME,STAT_CD) VALUES (?,?,?,?)";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/JDBCDemo", "root", "password");
             
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, 87);
            pstmt.setString(2, "Lokesh");
            pstmt.setString(3, "Gupta");
            pstmt.setInt(4, 5);
            int affectedRows = pstmt.executeUpdate();
            System.out.println(affectedRows + " row(s) affected !!");
        } 
        catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                pstmt.close();
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

