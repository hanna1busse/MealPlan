/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Notes;
import java.sql.*;
//Open the connection, query the database, return a resultset.
public class OpenCon {
    public static ResultSet a (String query) {
        String address = "jdbc:derby://localhost:1527/Food";
        //try-catch block, statment.close() will close the connection.
        try {        
             Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet resultset = st.executeQuery(query);
                 /* st.close();
                  connection.close();*/
                                  return resultset;
    }
        catch (SQLException s){
System.out.println("SQL exception ah!"+s.toString()+""+s.getErrorCode()+""+s.getSQLState());
        }
        catch (Exception e){
            System.out.println("Other exception");
        }
}
}
