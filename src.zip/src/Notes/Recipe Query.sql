SELECT * 
from PB_AND_J
inner join recipes on pb_and_j.recipe_id = recipes.recipe_id;