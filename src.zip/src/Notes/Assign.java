/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Notes;

import Notes.OpenCon;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author hanna
 */
public class Assign {
    public static void variables(){
        try {
            String query = "SELECT * from RECIPES where ISBREAKFAST = TRUE";        
            ResultSet rs= OpenCon.a(query);
       
        while (rs.next()) {
            int id = rs.getInt("RECIPE_ID");
            String name = rs.getString("RECIPE_NAME");
            String direct = rs.getString("DIRECTIONS");
            boolean bf = rs.getBoolean("ISBREAKFAST");
            System.out.println(direct);
        }}
    catch (SQLException s){
System.out.println("SQL exception ah!"+s.toString()+""+s.getErrorCode()+""+s.getSQLState());
        }
        catch (Exception e){
            System.out.println("Other exception");
        }}}