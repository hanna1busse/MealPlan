/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

/**
 *
 * @author hanna
 */
public class Alphabetical {
    String[][] order(String[][] foodgroup){
        String[][] newFoodgroup = new String[4][5];
        String tocheck="";
        int i=0;
        //set tocheck
        for(i=0;i<foodgroup.length;i++){
            tocheck=foodgroup[i][0];
        if(tocheck.equals("Dairy")){
            for(int j=0;j<foodgroup[0].length;j++){
          newFoodgroup[0][j] = foodgroup[i][j];
                  }
        }
         if(tocheck.equals("Fruit/ Veg")){
            for(int j=0;j<foodgroup[0].length;j++){
          newFoodgroup[1][j] = foodgroup[i][j];
                  }
        }
          if(tocheck.equals("Grains")){
            for(int j=0;j<foodgroup[0].length;j++){
          newFoodgroup[2][j] = foodgroup[i][j];
                  }
        }
           if(tocheck.equals("Protein")){
            for(int j=0;j<foodgroup[0].length;j++){
          newFoodgroup[3][j] = foodgroup[i][j];
                  }
        }
    }
        return newFoodgroup;
}
}
