/*
This finds how close a string is to another string (or, in this case, how close a recipe combo is to the ideal.)
 */
package mealplan;

/**
 *
 * @author hanna
 */
public class Levenshtein {

    /**
     * @param args the command line arguments
     */
     int distance(String fr, String tr) throws Exception {
        //declare strings, initialize variables
       String from = " ".concat(fr);
       String to = " ".concat(tr);
       int a = 0;
       int b=0;
       int left = 0;
       int top = 0;
       int corner = 0;
       int[][] calctable = new int[from.length()][to.length()];
       /////first column and row filled
       for(b=0; b<to.length(); b++){
           calctable[0][b] = b;
       }
       for(a=1; a<from.length(); a++){
           calctable[a][0] = a;
       }
       //second row! start comparing and matching
       for(b=1; b<to.length(); b++){
       for(a=1; a<from.length();a++){
           char f = from.charAt(a);
           char t = to.charAt(b);
       //set corner, left, and top           
//working on [1][1]
           left = calctable[a][b-1];
           corner = calctable[a-1][b-1] ;
           top = calctable[a-1][b];
       if(f==t){
        calctable[a][b]=corner;
       // System.out.println("match");
       //// 
   //  System.out.println(f+"!"+t);
    }else{
            if(left<corner){
               if(left<top){
                   //left<corner and top, set to left+
                   calctable[a][b]=left+1;
               }else{
                   //top<left<corner, set to top+
                   calctable[a][b]=top+1;
               }
           }else{
               //corner<left
               if(corner<top){
                   //corner<top and left, set to corner+
                   calctable[a][b]=corner+1;
               }else{
               //top<corner<left, set to top+
               calctable[a][b]=top+1;
               }
       //    System.out.println(f+""+t);

       }
}
    }}
   // PrintArray print = new PrintArray();
     //xprint.two(calctable,from.length(), to.length());
     return calctable[from.length()-1][to.length()-1];
    }}
    
