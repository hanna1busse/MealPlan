/*
 This will print a table from the database using a SQL query.
 */
package mealplan;
import java.sql.*;
//I'll actually need to use this one cause I can't close the connection until after I print.
public class PrintTable {
    void printT (String query) {
        String address = "jdbc:derby://localhost:1527/Food";
        //try-catch block, statment.close() will close the connection.
        try {        
             Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet resultset = st.executeQuery(query);
                 ResultSetMetaData rsmd = resultset.getMetaData();
  
      
            int numberOfColumns = rsmd.getColumnCount();
            
           for (int i = 1; i <= numberOfColumns; i++) {
        if (i > 1) System.out.print(",  ");
        String columnName = rsmd.getColumnName(i);
        System.out.print(columnName);
      }
             System.out.println("");
             
             while (resultset.next()) {
        for (int i = 1; i <= numberOfColumns; i++) {
          if (i > 1) System.out.print(",  ");
          String columnValue = resultset.getString(i);
          System.out.print(columnValue);
        }
        System.out.println("");  
      }
 st.close();
      connection.close();
    
              
    }
        catch (SQLException s){
System.out.println("SQL exception ah!"+s.toString()+""+s.getErrorCode()+""+s.getSQLState());
        }
        catch (Exception e){
            System.out.println("Other exception");
        }
}
}
