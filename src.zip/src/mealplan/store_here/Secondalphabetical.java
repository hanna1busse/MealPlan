/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

/**
 *
 * @author hanna
 */
public class Secondalphabetical {
      //actually input string, return string in alphabetical order.
  String order(String string){
  String[] split = new String[string.length()];
  int i, j;
  String hold = "";
  // put each letter in its own string in an array///////
  for(i=0;i<split.length;i++){
    split[i]=string.substring(i,i+1);
    //System.out.println(split[i]);
  }
  // compare the letters and put in order
        for(j=0;j<split.length;j++){
        for(i=0;i<split.length-1;i++){
          int c = split[i].compareTo(split[i+1]);
            if(c>0){
                //the characters need to be switched
                hold=split[i+1].concat(split[i]);
                split[i]=hold.substring(0,1);
                split[i+1]=hold.substring(1,2);
            } //needs more repeats
            }}
        
  //
   // returns an int, compares two strongs using unicode values.higher letter has greater value.
   convertarray ca= new convertarray();
    String extra=ca.tostring(split);
    return extra;
    }
}
