/*
Breakfast.getName() connects to the database and returns the least frequently used breakfast recipe by name
Breakfast.foodg() connects to the database and returns an array of foodgroups of that breakfast recipe (.getName must be run first.)
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author hanna
 */

//Get minimum of tracker column, increase tracker column by 1, write new value to database.
//This will give me breakfast. kinda.a start.
public class Breakfast {
    private int id;
    private int NumberofIngredients;
//returns name of breakfast recipe
    String getName(){
        try {
            String address = "jdbc:derby://localhost:1527/Food";
            String query = "SELECT MIN(TRACK) from RECIPES where ISBREAKFAST = TRUE";        
        //try-catch block, statment.close() will close the connection.     
        
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
            /////////////////////////////
       rs.next();
       int track = rs.getInt("1");
       
                  
       //////////////////////////////
       query = "SELECT * from RECIPES where TRACK = "+ track +" AND ISBREAKFAST = TRUE";        
           rs = st.executeQuery(query);
               
      
               
               
               /////////////////////////////
        rs.next();
            id = rs.getInt("RECIPE_ID");
            String name = rs.getString("RECIPE_NAME");
            String direct = rs.getString("DIRECTIONS");
            boolean bf = rs.getBoolean("ISBREAKFAST");

          /////////////////////
                   
          track++;
      String update = "UPDATE RECIPES SET TRACK = "+track+" WHERE recipe_id = "+id;
      st.executeUpdate(update);

    /* //////////////////did it work?
      query = "SELECT * from RECIPES WHERE recipe_id = "+id;
      rs = st.executeQuery(query);
                   ///////////////
                   rs.next();
                   track = rs.getInt("TRACK");
System.out.println(track);*/
                   ////////////
                   st.close();
                   connection.close();
                   //////////////
                   return name;
                           }
    catch(SQLException s){
System.out.println("SQL exception ah!"+s.toString()+""+s.getErrorCode()+""+s.getSQLState());
        }
        catch(Exception e){
            System.out.println("Other exception");
        }}    
    //returns array of food groups of breakfast recipe
    String[][] foodg() throws SQLException, Exception {
        String address = "jdbc:derby://localhost:1527/Food";
                String query = "Select count(*) from R"+id;

        //try-catch block if there's an error, statment.close() will close the connection.
        //try {        
             Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet resultset = st.executeQuery(query);  
                resultset.next();
            //HOW MANY INGREDIENTS?    
      NumberofIngredients = resultset.getInt(1);
      
    String[] ingredientID =  new String[NumberofIngredients];      
      /////////////////////
             //get each row's ingredient id, load it into the array.
      query = "Select ingredient_id from R"+id;
      resultset = st.executeQuery(query);
      int i = 0; 
      while(resultset.next()){
          ingredientID[i] = resultset.getString("ingredient_id");
          i++;
    }
      //match ingredient id to ingredient food group
      String[][] foodgroup = new String[NumberofIngredients][2];
      i=0;
      while(i<NumberofIngredients){
      query = "Select Food_Group1, Food_Group2 from Ingredients where ingredient_id = "+ingredientID[i];
      resultset = st.executeQuery(query);
      resultset.next();
      foodgroup[i][0] = resultset.getString("Food_Group1");
      foodgroup[i][1] = resultset.getString("Food_Group2");
      //a lot of foodgroup[][2] is going to be null values! remember that!
      i++;
      }
    

      /////////
    i=0;
while(i<NumberofIngredients){
    System.out.println(foodgroup[i][0]);
    System.out.println(foodgroup[i][1]);
    i++;
}
      //////
 st.close();
      connection.close();
    
              
  /*  }
        catch (SQLException s){
System.out.println("SQL exception ah!"+s.toString()+""+s.getErrorCode()+""+s.getSQLState());
        }
        catch (Exception e){
            System.out.println("Other exception");
        }*/

        /////////Which food group is each ingredient a part of? How many servings?
        //issue: number of ingredients varries with recipe.
    return foodgroup;
    }}
    /*use the SQL count(*) all function to get number of ingredients.
    public static void main(String args[]) throws Exception {
      //Registering the Driver
      DriverManager.registerDriver(new com.mysql.jdbc.Driver());
      //Getting the connection
      String mysqlUrl = "jdbc:mysql://localhost/mydatabase";
      Connection con = DriverManager.getConnection(mysqlUrl, "root", "password");
      System.out.println("Connection established......");
      //Creating a Statement object
      Statement stmt = con.createStatement();
      //Retrieving the data
      ResultSet rs = stmt.executeQuery("select count(*) from MyPlayers");
      rs.next();
      //Moving the cursor to the last row
      System.out.println("something contains "+rs.getInt("count(*)")+" rows");
   }
        }
        }
    }
*/

