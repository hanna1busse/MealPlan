/*
. * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan.store_here;

import mealplan.*;

/**
 *
 * @author hanna
 */
public class convertarray2 {
    String tostring(String array[]){
        int i;
        String voila="";
        for(i=0;i<array.length;i++){
            voila=voila.concat(array[i]);
           // System.out.println(voila);
        }
        return voila;
    }
    
}
