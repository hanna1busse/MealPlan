/*
This class/ method creates a second string if there's an entry in "FoodGroup2"
 */
package mealplan;

/**
 *
 * @author hanna
 */
public class transfer {
    String thing(String array[][]){
  int i=0;
  String result1="";
  String result2="";
  String sub1 = "";
  String sub2="";
  //////////////////////
  for(i=0;i<array.length;i++){
    result1=result1.concat(array[i][0].substring(0,1));
    System.out.println(result1);
  }
  ////////////////////////
  for(i=0;i<array.length;i++){
  if(array[i][1]!=null){
  sub1=result1.substring(0,i);
  sub2=result1.substring(i+1);
  sub1=sub1.concat(array[i][1].substring(0,1));
  result2=sub1.concat(sub2);
  System.out.println(result2);
    }
  }
  result1=result1.concat(result2);
  return result1;
  }
}
