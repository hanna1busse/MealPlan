/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hanna
 */
public class RecipeID {
    String ID="";
    int Next(int numberoftimes, String meal) throws SQLException{
        //get the recipe id for the lunch recipe
          String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select Recipe_ID from Storage";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
//loop this to get to the correct line, I guess?
               for(int i=0; i<numberoftimes;i++){
                rs.next();}
                String allthree = rs.getString("Recipe_ID");
                    //////Close connection to database
 st.close();
      connection.close();
      ///////
      ID = allthree;
      /////////separate string 
      String breakfast = allthree.substring(0,1);
      String lunch = allthree.substring(1,2);
      String dinner = allthree.substring(2,3);
      ////convert strings to integers
      int bfast = Integer.parseInt(breakfast);
      int lnch = Integer.parseInt(lunch);
      int dnnr = Integer.parseInt(dinner);
      ////
      //Use if statements and input to return breakfast/lunch/dinner depending on what's needed
      if(meal.equals("breakfast")){
          return bfast;
      } 
      if(meal.equals("lunch")){
          return lnch;
      }
      if(meal.equals("dinner")){
          return dnnr;
      }else{
          System.out.println("That's not a meal!");
          return 99999;
      }
    }
    String All(){
    return ID;
}
}
