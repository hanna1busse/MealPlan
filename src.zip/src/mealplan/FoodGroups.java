/*
 This is half-done.Right now, it's spitting out an array of strings for the first breakfast recipe's foodgroups.
The goal is to build an array that contains strings representing BLD combos by food group.
rules: lunch and dinner cannot be the same
for now, ignore frequency
if there are optional items, create two combos, one with option and one without.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author hanna
 */
public class FoodGroups {
   private int recipeID;
     String[][] get(int ID) throws SQLException, Exception{
           //count recipes
           recipeID = ID;
           int i;
            String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select count(*) from R"+recipeID;               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                rs.next();
            //HOW MANY INGREDIENTS?    
    int NumberofIngredients = rs.getInt(1);
      
    String[] ingredientID =  new String[NumberofIngredients];      
      /////////////////////
             //get each row's ingredient id, load it into the array.
      query = "Select ingredient_id from R"+recipeID;
      rs = st.executeQuery(query);
      i = 0; 
      while(rs.next()){
          ingredientID[i] = rs.getString("ingredient_id");
          i++;
    }
      //match ingredient id to ingredient food group
      String[][] foodgroup = new String[NumberofIngredients][5];
      i=0;
      while(i<NumberofIngredients){
      query = "Select Food_Group1, Food_Group2, Serving_size, unit from Ingredients where ingredient_id = "+ingredientID[i];
      rs = st.executeQuery(query);
      rs.next();
      foodgroup[i][0] = rs.getString("Food_Group1");
      foodgroup[i][1] = rs.getString("Food_Group2");
      foodgroup[i][2] = rs.getString("Serving_Size");
      foodgroup[i][3] = rs.getString("unit");
      //a lot of foodgroup[][2] is going to be null values! remember that!
      i++;
      }
    i=0;
      while(i<NumberofIngredients){
      query = "Select ingredient_amount from R"+recipeID+" where ingredient_id = "+ingredientID[i];
      rs = st.executeQuery(query);
      rs.next();
      foodgroup[i][4] = rs.getString("Ingredient_Amount");
      i++;
      }

      /////////
 //   i=0;
//while(i<NumberofIngredients){
  //  System.out.println(foodgroup[i][0]);
   // System.out.println(foodgroup[i][1]);
//    i++;
//}
      //////
 st.close();
      connection.close();
    
          /////
    return foodgroup;
    }
int recID(){
    return recipeID;
}
}
     