/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

/**
 *
 * @author hanna
 */
public class PrintArray {
    void go(String[][] array, int size)throws Exception{
//code to print array from here, instead of within my methods/ classes
int i=0;
while(i<size){
    System.out.println(array[i][0]);
    System.out.println(array[i][1]);
    i++;
}
}
     void two(String[][] array)throws Exception{
      int i=0;
      int j=0;
      while(i<array.length){
      while(j<array[0].length){
          System.out.print(array[i][j]+", ");
          j++;
      }
      j=0;
      System.out.println("break");
      i++;
      }  }
     void smol(double array[]){
         int i;
         for(i=0;i<array.length;i++){
             System.out.println(array[i]);
         }
     }
     void onestring(String array[]){
          int i;
         for(i=0;i<array.length;i++){
             System.out.println(array[i]);
         }
     }
     void integer(int array[]){
          int i;
         for(i=0;i<array.length;i++){
             System.out.println(array[i]);
         }
     }
     void lorgint(int[][] array)throws Exception{
      int i=0;
      int j=0;
      while(i<array.length){
      while(j<array[0].length){
          System.out.print(array[i][j]+", ");
          j++;
      }
      j=0;
      System.out.println("break");
      i++;
      }  }
}
