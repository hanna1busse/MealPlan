/*
. * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

/**
 *
 * @author hanna
 */
public class convertarray {
    double[] toDoubleArray(String sArray[][]){
        //use with foodgroup array
        //take the foodgroup array, divide amount of ingredient in recipe by amount of ingredient per serving to get servings per recipe  
        int i =0;
        int a =0;
        int b=0;
        double[] foodgroup2 = new double[sArray.length];
        for(i=0;i<foodgroup2.length;i++){
            if(sArray[i][4]!=null && sArray[i][2]!=null){
        foodgroup2[i]=Double.parseDouble(sArray[i][4])/Double.parseDouble(sArray[i][2]);
                }}
                return foodgroup2;
    }
    String tostring(String array[]){
        int i;
        String voila="";
        for(i=0;i<array.length;i++){
            voila=voila.concat(array[i]);
           // System.out.println(voila);
        }
        return voila;
}
}
