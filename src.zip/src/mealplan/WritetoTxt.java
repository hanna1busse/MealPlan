/*
 This will build a string from an array and write it to a text file. Or something like that.
 */
package mealplan;
   import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
 
/**
 *
 * @author hanna
 */
public class WritetoTxt {
 
/**
 * This program demonstrates how to write characters to a text file
 * using a BufferedReader for efficiency.
 * @author www.codejava.net
 *
 */
    void buildfromarray(String[][] array){
    int i=0; 
      //i correlates to number of rows
      int j=0;
      //j correlates to number of columns, use array[0].length for this
      String thestring;
      String addtostring;
      //now for columns
      for(i=0;i<array.length;i++){
          thestring = "";
           //System.out.println("start the first loop"+i+"and"+j);
      //write all the info in row i.
      for(j=0;j<array[i].length;j++){
          if(j == array[i].length-1)
          {addtostring = array[i][j];}
          else{
    addtostring = array[i][j]+", ";}
              thestring = thestring+addtostring;
          }
      //end second while
  //    System.out.println(thestring);
      //print to text file
      WritetoTxt test = new WritetoTxt();
      test.write(thestring);
      
    }
    }
    void write(String data) {
        BufferedWriter bw = null;
      try {
         //Specify the file name and path here. CAN BE A PATH
FileWriter file = new FileWriter("MealPlan.txt", true);
	 /* This logic will make sure that the file 
	  * gets created if it is not present at the
	  * specified location*/

	  bw = new BufferedWriter(file);
	  bw.write(data);
          bw.newLine();
          System.out.println("File written Successfully");

      } catch (IOException ioe) {
	}
	finally
	{ 
	   try{
	      if(bw!=null)
		 bw.close();
	   }catch(Exception ex){
	       System.out.println("Error in closing the BufferedWriter"+ex);
 
    }
 
}
    }
    void cookplan(String data) {
        BufferedWriter bw = null;
      try {
         //Specify the file name and path here. CAN BE A PATH
FileWriter file = new FileWriter("CookingPlan.txt", true);
	 /* This logic will make sure that the file 
	  * gets created if it is not present at the
	  * specified location*/

	  bw = new BufferedWriter(file);
	  bw.write(data);
          bw.newLine();
          System.out.println("File written Successfully");

      } catch (IOException ioe) {
	}
	finally
	{ 
	   try{
	      if(bw!=null)
		 bw.close();
	   }catch(Exception ex){
	       System.out.println("Error in closing the BufferedWriter"+ex);
 
    }
 
}
    }
}