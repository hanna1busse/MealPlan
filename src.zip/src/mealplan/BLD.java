/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hanna
 */
public class BLD {
    void whatNext() throws SQLException, Exception{
             String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select count(*) from Storage";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                rs.next();
            //HOW MANY COMBOS?    
    int NumberofCombos = rs.getInt(1);
     st.close();
      connection.close();
      /////////
    for(int k=0;k<NumberofCombos;k++){  
    //get the recipe id for the breakfast recipe
        RecipeID ID = new RecipeID();
        int recipeID = ID.Next(k+1,"breakfast");
        //put into FoodGroups
    FoodGroups fg = new FoodGroups();
    String array[][]=fg.get(recipeID);
            //returns String[][] of food group name that I then use to calculate servings per recipe.serving
            //put into Alphabetical.order, which puts all strings into a standard order
    Alphabetical abc = new Alphabetical();
    array = abc.order(array);
    ///////
    PrintArray pa = new PrintArray();
   // pa.two(array);
            //returns String[][] in standard order
        //put into convertarray.toDoubleArray, which converts strings to doubles and performs calculations
    convertarray ca = new convertarray();
    double[] bfast_fg = ca.toDoubleArray(array);
        //returns double[] of food group servings in one serving of the recipe 
///       
        
//get the recipe id for the lunch recipe
        recipeID = ID.Next(k+1,"lunch");
        //put into FoodGroups
    array=fg.get(recipeID);
            //returns String[][] of food group name that I then use to calculate servings per recipe.serving
            //put into Alphabetical.order, which puts all strings into a standard order
    array = abc.order(array);
    ///////
  //  pa.two(array);
            //returns String[][] in standard order
        //put into convertarray.toDoubleArray, which converts strings to doubles and performs calculations
    double[] lunch_fg = ca.toDoubleArray(array);
        //returns double[] of food group servings in one serving of the recipe 
///       
// ???? here I write something new
        //add these doubles to the doubles from the breakfast recipe
        double[] total_fg = new double[4];
        for(int i=0;i<4;i++){
            total_fg[i]=bfast_fg[i]+lunch_fg[i];
        }
        //
        //pa.smol(total_fg);
        //repeat for dinner (CONSIDER DINNER HAS A SECOND FOOD GROUP OPTION!)
        //get the recipe id for the dinner recipe
        recipeID = ID.Next(k+1,"dinner");
        //put into FoodGroups
    array=fg.get(recipeID);
            //returns String[][] of food group name that I then use to calculate servings per recipe.serving
            //put into Alphabetical.order, which puts all strings into a standard order
    array = abc.order(array);
    //returns String[][] in standard order
        //put into convertarray.toDoubleArray, which converts strings to doubles and performs calculations
    double[] dinner_fg = ca.toDoubleArray(array);
        //returns double[] of food group servings in one serving of the recipe 
///       
        //add dinner to breakfast and lunch
        for(int i=0;i<4;i++){
            total_fg[i]=total_fg[i]+dinner_fg[i];
        }
      //  pa.smol(total_fg);
        //get distance from combo to ideal
        
            ////add or alter meals? or should I kinda just do this before hand in the database, like double servings and stuff?
            ////save to database
            String fullrecipeID = ID.All();
            int i=Integer.parseInt(fullrecipeID);
            ToDatabase todatabase = new ToDatabase();
            todatabase.Writeservings(i, total_fg);
            ////get distance
            double[] distance = new double[4];
            distance[0]=3-total_fg[0];
            distance[1]=4.5-total_fg[1];
            distance[2]=6-total_fg[2];
            distance[3]=5.5-total_fg[3];
            
            double dist=0;
            for(int j=0;j<distance.length;j++){
            dist = dist + distance[j];    
            }
        //save to database
        todatabase.Writedistance(i, dist);
    }
    }
}
