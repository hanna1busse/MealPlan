/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

/**
 *
 * @author hanna
 */
public class Math {
    int factorial(int number){
          int i,fact=1;  
  for(i=1;i<=number;i++){    
      fact=fact*i;
  }    
  return fact;
    }
    int combinations(int total, int groups, int breakfast){
        Math math = new Math();
        int n = math.factorial(total);
        int k = math.factorial(groups);
        int nlessk = math.factorial(total-groups);
        int ld = n/(k*nlessk);
        return ld*breakfast;
    }
    int ldcombos(int total, int groups){
         Math math = new Math();
        int n = math.factorial(total);
        int k = math.factorial(groups);
        int nlessk = math.factorial(total-groups);
        return n/k*nlessk;
    }
}
