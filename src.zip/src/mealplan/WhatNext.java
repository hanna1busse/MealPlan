/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hanna
 */
public class WhatNext {
            //pull least distance, and use as meal plan (BUT, consider other factors, like pantry inventory and frequency of eating.)
String[] schedule() throws SQLException{
    String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(DISTANCE) FROM STORAGE";              
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
rs.next();
int length = rs.getInt(1);
double[] distance = new double[length];
query = "SELECT DISTANCE FROM STORAGE";
rs = st.executeQuery(query);
for(int i=0;i<length;i++){
    rs.next();
distance[i]=rs.getDouble("Distance");
}
//////////////////////////////
double[] plan = new double[5];
int delete = 0;
//////make plan[0] the minimum value
for(int j =0;j<5;j++){
plan[j] = distance[0]; 
    for(int i=1;i<distance.length;i++){ 
      if(distance[i] < plan[j]){ 
        plan[j] = distance[i]; 
        delete = i;
      } 
    }
    distance[delete] = 999;
    //System.out.println(plan[j]);
}
///////////////////////
//get recipe ids
String[] mealplan = new String[5];
for(int i=0;i<plan.length;i++){
query = "SELECT RECIPE_ID FROM STORAGE WHERE DISTANCE = "+plan[i];
rs = st.executeQuery(query);
rs.next();
mealplan[i]=rs.getString("RECIPE_ID");
//System.out.println(mealplan[i]);
        }
//////////////////////////
//another big loop
WritetoTxt write = new WritetoTxt();
write.write("Day of the Week,Breakfast,Lunch,Dinner");
////parse strings
for(int i=0;i<5;i++){
String breakfast = "";
String lunch = "";
String dinner = "";
breakfast = mealplan[i].substring(0,1);
lunch = mealplan[i].substring(1,2);
dinner = mealplan[i].substring(2,3);
/////////
//GET RECIPE NAMES
query = "SELECT RECIPE_NAME FROM RECIPES WHERE RECIPE_ID = "+breakfast;
rs = st.executeQuery(query);
rs.next();
breakfast=rs.getString("RECIPE_NAME");
//System.out.println(breakfast);
query = "SELECT RECIPE_NAME FROM RECIPES WHERE RECIPE_ID = "+lunch;
rs = st.executeQuery(query);
rs.next();
lunch=rs.getString("RECIPE_NAME");
//System.out.println(lunch);
query = "SELECT RECIPE_NAME FROM RECIPES WHERE RECIPE_ID = "+dinner;
rs = st.executeQuery(query);
rs.next();
dinner=rs.getString("RECIPE_NAME");
//System.out.println(dinner);
////////////////
//write to csv
String day;
        switch (i) {
            case 0:
                day="Monday";
                break;
            case 1:
                day="Tuesday";
                break;
            case 2:
                day="Wednesday";
                break;
            case 3:
                day="Thursday";
                break;
            default:
                day="Friday";
                break;
        }
write.write(day+","+breakfast+","+lunch+","+dinner);
}
 st.close();
      connection.close();
return mealplan;
}
String[][] cookingplan() throws SQLException, Exception{
    WhatNext wn = new WhatNext();
    String [] mealplan=wn.schedule();
    /////////////////////////
    //do I also need a cooking plan? like double this recipe, make one of this and freeze two portions for later, etc.?
    ///FIRST MAKE THREE SUBSTRINGS  
    //consider: it's faster to do this with math.
        String[] mealarray = new String[mealplan.length*3];
        int z=0;
    for(int i=0;i<mealplan.length;i++){
    mealarray[z]=mealplan[i].substring(0,1);
    mealarray[z+1]=mealplan[i].substring(1,2);
    mealarray[z+2]=mealplan[i].substring(2,3);
    z=z+3;
    }
    //////////////////////////////////////////////////
    //parse from strings to integers
    //create MealArray ma, which holds integers
   int[] ma = new int[mealarray.length];
    for(int i=0;i<ma.length;i++){
          ma[i]=Integer.parseInt(mealarray[i]);
        }
    /////////////////////////////////////////////////////////
    //order from low to high
int temp=0;
for(int i=0;i<ma.length;i++){
    for (int b = 0; b < ma.length-1; ++b) {
        if (ma[b] > ma[b + 1]) {
            temp = ma[b];
            ma[b] = ma[b + 1];
            ma[b + 1] = temp;
        }
    }}
        PrintArray pa=new PrintArray();
//pa.integer(ma);
      ///////////
      //create ma without duplicates, by first counting unique recipe ids
      int count=0;
      boolean isunique=true;
      //count how many numbers do not match the first one  
   for(int i=0;i<ma.length;i++){
       isunique=true;
      for(int k=i+1;k<ma.length;k++){
          if(ma[i]==ma[k]){
              isunique=false;
          }
      }
      if(isunique==true){
       count++;
   }
   }
    // Create meal array maNoDup (meal array no duplicates), which holds integers of unique recipe IDs (no duplicates)
      int[] maNoDup=new int[count];
                int c=0;
        for(int i=0;i<ma.length;i++){
       isunique=true;
      for(int k=0;k<c;k++){
          //only looping until k/c because c is the last piece of data input in the array.
          if(ma[i]==maNoDup[k]){
              isunique=false;
          }
      }
      if(isunique==true){
       maNoDup[c]=ma[i];
       c++;
   }
   }
     //   pa.integer(maNoDup);
        //count instances of each meal in the meal plan in a handy dandy array!
    
    int[][] countofmeals = new int[maNoDup.length][2];
    
      //set column 0 equal to unique Recipe IDs.
      for(int i=0;i<maNoDup.length;i++){
          countofmeals[i][0]=maNoDup[i];
      }
////////////
for(int i=0;i<countofmeals.length;i++){
        int mcount=0;
        for(int k=0;k<ma.length;k++){
        if(countofmeals[i][0]==ma[k]){
            mcount++;
        }   
        }
        //System.out.println(countofmeals[i][0]+", "+mcount);
        countofmeals[i][1]=mcount;
    }
    //pa.lorgint(countofmeals)
//////////////////////////////////////////////    
//how many of each recipe do i make to get this many servings?
       String address = "jdbc:derby://localhost:1527/Food";
            String query = "SELECT COUNT(RECIPE_ID) FROM RECIPES";              
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
                rs.next();
                int l=rs.getInt(1);
                String[][] newdata = new String[l][3];
                //
            query="Select RECIPE_ID, HOW_MANY_SERVINGS, RECIPE_NAME FROM RECIPES";
            rs = st.executeQuery(query);
            for(int i=0;i<newdata.length;i++){
                rs.next();
                newdata[i][0]=rs.getString("RECIPE_ID");
                newdata[i][1]=rs.getString("HOW_MANY_SERVINGS");
                newdata[i][2]=rs.getString("RECIPE_NAME");
            }
           st.close();
      connection.close();
      ///////////////////
      //one larger array
        //COL. 0= recipe IDs
        //col. 1= recipe name
        //col. 2= count of servings neede for meal plan
        //col. 3= # of servings that one recipe makes
        //col. 4=number of times to make each recipe
        //col. 5=leftover servings to freeze
        String[][] plandata = new String[countofmeals.length][6];
        for(int i=0;i<plandata.length;i++){
            plandata[i][0]=Integer.toString(countofmeals[i][0]);
            plandata[i][2]=Integer.toString(countofmeals[i][1]);
        }
        ///////////////////////
        for(int k=0;k<plandata.length;k++){
      for(int i=0;i<newdata.length;i++)
      if(plandata[k][0].equals(newdata[i][0])){
    plandata[k][1]=newdata[i][2];
    plandata[k][3]=newdata[i][1];
      }
        }
        /////////////////////////////////
        //divide col2/col3, round up
                //remainder
        int remainder=0;
        for(int i=0;i<plandata.length;i++){
        temp=Integer.parseInt(plandata[i][2])/Integer.parseInt(plandata[i][3]);
        remainder=Integer.parseInt(plandata[i][2])%Integer.parseInt(plandata[i][3]);
        if(remainder!=0){
            temp++;
            remainder=Integer.parseInt(plandata[i][3])*temp-Integer.parseInt(plandata[i][2]);
        }
        plandata[i][4]=Integer.toString(temp);
        plandata[i][5]=Integer.toString(remainder);
        }
        
        //pa.two(plandata);
        
       //WRITE TO FILE :D
       WritetoTxt write = new WritetoTxt();
write.cookplan("Recipe, Number of Batches, Expected Total Servings, Leftover Servings");
//COL. 0= recipe ID
        //col. 1= recipe name
        //col. 2= count of servings neede for meal plan
        //col. 3= # of servings that one recipe makes
        //col. 4=number of times to make each recipe
        //col. 5=leftover servings to freeze
for(int i=0;i<plandata.length;i++){
        temp=Integer.parseInt(plandata[i][3])*Integer.parseInt(plandata[i][4]);
write.cookplan(plandata[i][1]+", "+plandata[i][4]+", "+temp+", "+plandata[i][5]);
}

pa.two(plandata);
return plandata;
}  

void ingredientlist() throws SQLException, Exception{
     WhatNext wn = new WhatNext();
    String [][] cookingplan=wn.cookingplan();
    //////////////////////////////////////
    String address = "jdbc:derby://localhost:1527/Food";
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                String query = "";              
                ResultSet rs;
                int totalIngredients=0;
                                //get length of array: get count of each recipe's ingredient list and add them up
                for(int i=0;i<cookingplan.length;i++){
                query = "SELECT COUNT(INGREDIENT_ID) FROM R"+cookingplan[i][0]; 
                rs= st.executeQuery(query);
                rs.next();
                totalIngredients=totalIngredients+rs.getInt(1); 
                }
                System.out.println("There are "+totalIngredients+" total ingredients for this plan.");
                //create list of all ingredients in all used recipes (pantry vs shopping list will come next, i think):
               String rawingredientlist[][]=new String[totalIngredients][4];
               //col 0: ingredient id
               //col 1: ingredient name
               //col 2: ingredient amount
               //col 3: unit of measure
               int z=0;
               for(int i=0;i<cookingplan.length;i++){
                query = "SELECT count(INGREDIENT_ID) FROM R"+cookingplan[i][0]; 
                rs= st.executeQuery(query);
                rs.next();
                int looplength=rs.getInt(1);
                  query = "SELECT INGREDIENT_ID, INGREDIENT_AMOUNT FROM R"+cookingplan[i][0]; 
                rs= st.executeQuery(query);
                  for(int k=0;k<looplength;k++){
                rs.next(); 
                rawingredientlist[z][0]=rs.getString("INGREDIENT_ID");
                rawingredientlist[z][2]=rs.getString("INGREDIENT_AMOUNT");
                z++;
                }   
               }
                  PrintArray pa=new PrintArray();
                  pa.two(rawingredientlist);
                //put names and units in array
               for(int i=0;i<rawingredientlist.length;i++){
                query = "SELECT INGREDIENT_NAME, UNIT FROM INGREDIENTS WHERE INGREDIENT_ID="+rawingredientlist[i][0]; 
                rs= st.executeQuery(query);
                rs.next(); 
                rawingredientlist[i][1]=rs.getString("INGREDIENT_NAME");
                rawingredientlist[i][3]=rs.getString("UNIT");
                }   
                  pa.two(rawingredientlist);
                //consolidate duplicates
                //count duplicates
                int countOfDuplicates=0;
                 for (int i = 0; i < rawingredientlist.length-1; i++)
        {
            for (int k = i+1; k < rawingredientlist.length; k++)
            {
                if ((Integer.parseInt(rawingredientlist[i][0]) == Integer.parseInt(rawingredientlist[k][0])) && (i != k))
                {
                    System.out.println("Duplicate Element : "+rawingredientlist[k][0]); 
                    countOfDuplicates++;}
            }}
                 //put the duplicates in an array
                 String[] duplicateIngredients = new String[countOfDuplicates];
                 countOfDuplicates=0;
                 for (int i = 0; i < rawingredientlist.length-1; i++)
        {
            for (int k = i+1; k < rawingredientlist.length; k++)
            {
                if ((Integer.parseInt(rawingredientlist[i][0]) == Integer.parseInt(rawingredientlist[k][0])) && (i != k))
                {
                    duplicateIngredients[countOfDuplicates]=rawingredientlist[k][0]; 
                    countOfDuplicates++;
                    }
            }}
                 //combine?
                 //rewiret array
                 String[][] ingredientList = new String[rawingredientlist.length-countOfDuplicates][4];
                 //col 0: ingredient id
               //col 1: ingredient name
               //col 2: ingredient amount
               //col 3: unit of measure
                 
                 //put in the unique recipe ids
                 boolean isunique=true;
                 //for(int i=0;i<ingredientList.length;i++){
                     for(int j=0;j<rawingredientlist.length;j++){
                         for(int k=0;k<duplicateIngredients.length;k++){
                     if(Integer.parseInt(rawingredientlist[j][0])==Integer.parseInt(duplicateIngredients[k]))
                     {
                    isunique=false; }
                         }
                         if(isunique==true){
               //  ingredientList[i][0]=rawingredientlist[j][0];
               System.out.println("Unique");
                       
                 }
                         else{
                             //isunique==false, it's a duplicate.
                             System.out.println(rawingredientlist[j][0]+" is a duplicate.");
                     }
                      isunique=true;}
                    
}
                 //does id=dupid?
                 //is it the first instance?
                 //if not, add to the first one
                 
                //write to file
}
}
        
}
}