/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hanna
 */
public class GetUIData {
    String recipename(int RecipeID) throws SQLException{
   String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select RECIPE_NAME from RECIPES where RECIPE_ID = "+RecipeID;               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);   
                rs.next();
                String name=rs.getString("RECIPE_NAME");
                return name;
    }
    String[][] ingredienttable() throws SQLException{
      String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select count(*) from INGREDIENTS";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                rs.next();
            //HOW MANY INGREDIENTS?    
    int NumberofIngredients = rs.getInt(1);
    String[][] array = new String[NumberofIngredients][4];
////////////////////////////
query="SELECT INGREDIENT_NAME, SERVING_SIZE, UNIT FROM INGREDIENTS";
               rs = st.executeQuery(query);
for(int i=0;i<array.length;i++){
    rs.next();
    array[i][0]=rs.getString("INGREDIENT_NAME");
    array[i][3]="("+rs.getString("SERVING_SIZE")+")";
    array[i][2]=rs.getString("UNIT");
}
        return array;
    }
    
}
