/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hanna
 */
public class ToDatabase {
    void WriterecipeID(String[] combos) throws SQLException, Exception {
        
        /////////////////////////////
        String address = "jdbc:derby://localhost:1527/Food";
                String query = "CREATE TABLE Storage (RECIPE_ID Int, DAIRY Double, FRUIT_VEG Double, GRAINS Double, PROTEIN Double, DISTANCE Double)";    
             Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                st.executeUpdate(query);  
                /////
                for(int i=0;i<combos.length;i++){
                query="INSERT INTO STORAGE (RECIPE_ID) VALUES ("+combos[i]+")";
                                st.executeUpdate(query);  
                }
                st.close();
      connection.close();
    }
void Writeservings(int recipeID, double[] sperr) throws SQLException{
     String address = "jdbc:derby://localhost:1527/Food";
             Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                //////insert servings per serving in database row... make more columns, one for each foodgroup, first!
               String query="UPDATE STORAGE SET DAIRY = "+sperr[0]+", FRUIT_VEG = "+sperr[1]+", GRAINS = "+sperr[2]+", PROTEIN = "+sperr[3]+" WHERE RECIPE_ID = "+recipeID;
st.executeUpdate(query); 
/////
 st.close();
      connection.close();
    }
void Writedistance(int recipeID, double distance) throws SQLException{
     String address = "jdbc:derby://localhost:1527/Food";
             Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                //////insert servings per serving in database row... make more columns, one for each foodgroup, first!
               String query="UPDATE STORAGE SET DISTANCE = "+distance+" WHERE RECIPE_ID = "+recipeID;
st.executeUpdate(query); 
/////
 st.close();
      connection.close();
    }
}

