/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hanna
 */
public class NewIngredient {
    String ID(String name) throws SQLException{
         String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(INGREDIENT_ID) from INGREDIENTS";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int numberofingredients = 0;
                rs.next();
                numberofingredients=rs.getInt(1);
                int newID=numberofingredients+1;
                 
/////////////////////////////////////////
query="SELECT INGREDIENT_NAME FROM INGREDIENTS";
rs = st.executeQuery(query);
String[] ingredients = new String[numberofingredients];
for(int i=0;i<ingredients.length;i++){
rs.next();
ingredients[i]= rs.getString("INGREDIENT_NAME");
}
/////////////////////////////////////////////
boolean itsaduplicate=false;
for(int i=0;i<ingredients.length;i++){
if(name.equals(ingredients[i])){
    itsaduplicate=true;
}
}
System.out.println(itsaduplicate);
if(itsaduplicate==true){
    return "This is a duplicate ingredient.";
}else{
query="INSERT INTO INGREDIENTS (INGREDIENT_ID, INGREDIENT_NAME) VALUES ("+newID+", '"+name+"')";
st.executeUpdate(query);
return "Added.";
}
    }
    void FoodGroup1(String fg1) throws SQLException{
          String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(INGREDIENT_ID) from INGREDIENTS";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int ID = 0;
                rs.next();
                ID=rs.getInt(1);                 
/////////////////////////////////////////
query="UPDATE INGREDIENTS SET FOOD_GROUP1 = '"+fg1+"' WHERE INGREDIENT_ID = "+ID;
st.executeUpdate(query); 
        
    }
      void FoodGroup2(String fg2) throws SQLException{
          String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(INGREDIENT_ID) from INGREDIENTS";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int ID = 0;
                rs.next();
                ID=rs.getInt(1);                 
/////////////////////////////////////////
query="UPDATE INGREDIENTS SET FOOD_GROUP2 = '"+fg2+"' WHERE INGREDIENT_ID = "+ID;
st.executeUpdate(query); 
        
    }
      String getName() throws SQLException{
          String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(INGREDIENT_ID) from INGREDIENTS";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int numberofingredients = 0;
                rs.next();
                numberofingredients=rs.getInt(1);
                 
/////////////////////////////////////////
query="SELECT INGREDIENT_NAME FROM INGREDIENTS WHERE INGREDIENT_ID = "+numberofingredients;
rs = st.executeQuery(query);
rs.next();
String name = rs.getString("INGREDIENT_NAME");
return name;
      }
      void Unit(String unit) throws SQLException{
          String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(INGREDIENT_ID) from INGREDIENTS";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int ID = 0;
                rs.next();
                ID=rs.getInt(1);                 
/////////////////////////////////////////
query="UPDATE INGREDIENTS SET UNIT = '"+unit+"' WHERE INGREDIENT_ID = "+ID;
st.executeUpdate(query); 
        
      }
    void ServingSize(double size) throws SQLException{
          String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(INGREDIENT_ID) from INGREDIENTS";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int ID = 0;
                rs.next();
                ID=rs.getInt(1);                 
/////////////////////////////////////////
query="UPDATE INGREDIENTS SET SERVING_SIZE = "+size+" WHERE INGREDIENT_ID = "+ID;
st.executeUpdate(query); 
    }
}
