/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**move from system print to writing to array!
 *
 * @author hanna
 */
public class Combos {
    String[] create()throws SQLException, Exception{
            String address = "jdbc:derby://localhost:1527/Food";
            String query = "SELECT Count(Recipe_ID) from RECIPES where ISBREAKFAST = true";          
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
        ////////////
                 //sELECT BREAKFAST RECIPE idS FROM DATABASE
                rs.next();
                int i=rs.getInt(1);
                int[] breakfast= new int[i];
///////////////////////////////////
               query = "SELECT Recipe_ID from RECIPES where ISBREAKFAST = true"; 
                              rs=st.executeQuery(query);
               //LOAD INTO ARRAY
             for(i=0;i<breakfast.length;i++){
               rs.next();
           breakfast[i] = rs.getInt("RECIPE_ID");
             }
             //////get array size for l/d
             query = "SELECT Count(Recipe_ID) from RECIPES where ISBREAKFAST = false"; 
              rs = st.executeQuery(query);
        ////////////create l/d array
                rs.next();
                i=rs.getInt(1);
                System.out.println(i);
                int[] lunchdinner= new int[i];
///////////////////////////////////select lunch/dinner recipe ids from database
               query = "SELECT Recipe_ID from RECIPES where ISBREAKFAST = false"; 
                              rs=st.executeQuery(query);
                     //store recipe IDs in an array
             for(i=0;i<lunchdinner.length;i++){
               rs.next();
           lunchdinner[i] = rs.getInt("RECIPE_ID");
             }
             //////
             //combos!
             Math math = new Math();
             String [] combos = new String[math.combinations(lunchdinner.length, 2, breakfast.length)];
             String combo = "";
             int j;
             int k;
             int l=0;
             for(i=0;i<breakfast.length;i++){
                 combo = ""+breakfast[i];
                 for(j=0;j<lunchdinner.length;j++){
                     combo = combo+lunchdinner[j];
                     for(k=0;k<lunchdinner.length;k++){
                       if(j<k){
                         combo=combo+lunchdinner[k];
                      //System.out.println(combo+"..."+l); 
                      combos[l]= combo;
                      l++;
                              }
                                   combo = ""+ breakfast[i]+lunchdinner[j];

                       }
                     }
                 combo=""+breakfast[i];
                 }
             ////
             //all of the combos are loaded into an array
            return combos; }
    void special() throws SQLException, Exception{
        Combos c=new Combos();
       String[] combos=c.create();
       String[][] result_array=new String[combos.length][2];
       for(int i=0;i<combos.length;i++){
           result_array[i][0]=combos[i];
       }
       //next write the numbers from convert array here
    }    
    double[] next() throws Exception{
        ///NOT USING THIS RIGHT NOW!
        //giant loop to get each recipe's food groups
        //how to set recipe id for this? go back through and trace the variable
        int recipeID = 1;
    FoodGroups fg = new FoodGroups();
    String array[][]=fg.get(recipeID);
    /////
    Alphabetical abc = new Alphabetical();
    array = abc.order(array);
    ///////
    PrintArray pa = new PrintArray();
    pa.two(array);
    //first, put everything in alphabetical order.
    //next make the numbers into doubles
    convertarray ca = new convertarray();
    double[] doub = ca.toDoubleArray(array);
    //
    return doub;
    }
    }

