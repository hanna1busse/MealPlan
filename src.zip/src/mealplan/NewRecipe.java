/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealplan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hanna
 */
public class NewRecipe {
    int add() throws SQLException{
     String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(Recipe_ID) from RECIPES";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int numberofrecipes = 0;
                rs.next();
                numberofrecipes=rs.getInt(1);
                int newrecipeID=numberofrecipes+1;
                 
/////////////////////////////////////////
query="INSERT INTO RECIPES (RECIPE_ID) VALUES ("+newrecipeID+")";
st.executeUpdate(query);
/////////////////////////////////////////////
query="CREATE TABLE R"+newrecipeID+" (RECIPE_ID INT, INGREDIENT_ID INT PRIMARY KEY, INGREDIENT_AMOUNT DECIMAL)";
st.executeUpdate(query);
    return newrecipeID;            
}
    void writename(String recipename) throws SQLException{
        String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(Recipe_ID) from RECIPES";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int numberofrecipes = 0;
                rs.next();
                numberofrecipes=rs.getInt(1);                 
/////////////////////////////////////////
query="UPDATE RECIPES SET RECIPE_NAME = '"+recipename+"' WHERE RECIPE_ID = "+numberofrecipes;
st.executeUpdate(query);           
    }
    void writeboolean(String isitb) throws SQLException{
        boolean b;
        b = isitb.equalsIgnoreCase("yes");
        String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(Recipe_ID) from RECIPES";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int numberofrecipes = 0;
                rs.next();
                numberofrecipes=rs.getInt(1);                 
/////////////////////////////////////////
query="UPDATE RECIPES SET ISBREAKFAST = "+b+" WHERE RECIPE_ID = "+numberofrecipes;
st.executeUpdate(query);           
    }
    void writeservings(int servings) throws SQLException{
            String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(Recipe_ID) from RECIPES";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int numberofrecipes = 0;
                rs.next();
                numberofrecipes=rs.getInt(1);                 
/////////////////////////////////////////
query="UPDATE RECIPES SET HOW_MANY_SERVINGS = "+servings+" WHERE RECIPE_ID = "+numberofrecipes;
st.executeUpdate(query);    
    }
    void writeDirections(String directions) throws SQLException{
           String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(Recipe_ID) from RECIPES";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int numberofrecipes = 0;
                rs.next();
                numberofrecipes=rs.getInt(1);                 
/////////////////////////////////////////
query="UPDATE RECIPES SET DIRECTIONS = '"+directions+"' WHERE RECIPE_ID = "+numberofrecipes;
st.executeUpdate(query);    
    }
    void writeingredients(int[] ingredients, double[] amounts) throws SQLException{
         String address = "jdbc:derby://localhost:1527/Food";
            String query = "Select COUNT(Recipe_ID) from RECIPES";               
        Connection connection = DriverManager.getConnection(address, "APP", " ");
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(query);
///////////////////////////////////
                int recipeID = 0;
                rs.next();
                recipeID=rs.getInt(1);                 
/////////////////////////////////////////
for(int i=0;i<ingredients.length;i++){
    int ingID = ingredients[i]+1;
/////////////////////////////////////////
query="INSERT INTO R"+recipeID+" VALUES ("+recipeID+", "+ingID+", "+amounts[i]+")";
st.executeUpdate(query);    
}
    }
}
